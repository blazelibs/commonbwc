
loc = 'blazewebtestapp2.components.tests.tasks.init_db'
loctoo = 'blazewebtestapp2.components.tests.tasks.init_db'

def action_001():
    return loctoo
