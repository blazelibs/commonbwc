
loc = 'blazewebtestapp.modules.tests.tasks.init_db'
