from blazeweb.content import Content, TemplateContent

class HwSnippet(Content):
    def create(self):
        return u'Hello World!'

