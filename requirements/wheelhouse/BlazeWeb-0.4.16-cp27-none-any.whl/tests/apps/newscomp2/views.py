
class FakeView(object):
    pass

class InNewsComp2(object):
    pass

class News1HasPriority(object):
    pass