
class AppLevelView(object):
    pass

class AppLevelView2(object):
    pass