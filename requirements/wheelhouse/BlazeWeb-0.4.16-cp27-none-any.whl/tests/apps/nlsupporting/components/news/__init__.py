
def somefunc():
    pass
