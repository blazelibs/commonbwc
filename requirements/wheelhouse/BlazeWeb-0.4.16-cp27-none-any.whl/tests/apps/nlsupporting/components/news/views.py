
class FakeView(object):
    pass

class InNlSupporting(object):
    pass

class InAppHasPriority(object):
    pass