
class FakeView(object):
    pass
