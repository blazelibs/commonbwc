
class FakeView(object):
    pass